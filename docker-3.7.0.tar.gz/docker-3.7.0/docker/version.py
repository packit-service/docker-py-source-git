version = "3.7.0"
version_info = tuple([int(d) for d in version.split("-")[0].split(".")])
